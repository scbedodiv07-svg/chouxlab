import { createPageUrl } from "@/utils";
import { Link } from "react-router-dom";
import { FlaskConical, Search, ChevronRight, Beaker } from "lucide-react";
import { motion } from "framer-motion";

export default function Home() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-amber-50 via-orange-50 to-yellow-50 flex flex-col items-center justify-center p-6">
      <motion.div
        initial={{ opacity: 0, y: -30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="max-w-2xl w-full text-center"
      >
        <div className="flex justify-center mb-6">
          <div className="bg-amber-600 rounded-full p-5 shadow-xl">
            <FlaskConical className="w-12 h-12 text-white" />
          </div>
        </div>

        <h1 className="text-4xl md:text-5xl font-bold text-amber-900 mb-3">
          Choux Pastry STEM Lab
        </h1>
        <p className="text-lg text-amber-700 mb-10">
          A virtual edible lab to explore the food science of choux pastry — steam expansion, starch gelatinization, and egg protein coagulation.
        </p>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-10">
          <motion.div whileHover={{ scale: 1.03 }}>
            <Link
              to={createPageUrl("Experiment")}
              className="bg-amber-600 hover:bg-amber-700 text-white rounded-2xl p-6 shadow-lg flex flex-col items-center gap-3 cursor-pointer transition-colors"
            >
              <div className="bg-amber-500 rounded-full p-3">
                <Beaker className="w-7 h-7 text-white" />
              </div>
              <h2 className="text-xl font-bold">Start Experiment</h2>
              <p className="text-sm text-amber-100">
                Follow the step-by-step Master Dough simulation. Mix, bake, and see your Pastry Profile.
              </p>
              <div className="flex items-center gap-1 text-amber-200 text-sm font-semibold mt-1">
                Begin <ChevronRight className="w-4 h-4" />
              </div>
            </Link>
          </motion.div>

          <motion.div whileHover={{ scale: 1.03 }}>
            <Link
              to={createPageUrl("Forensics")}
              className="bg-orange-700 hover:bg-orange-800 text-white rounded-2xl p-6 shadow-lg flex flex-col items-center gap-3 cursor-pointer transition-colors"
            >
              <div className="bg-orange-600 rounded-full p-3">
                <Search className="w-7 h-7 text-white" />
              </div>
              <h2 className="text-xl font-bold">Culinary Forensics</h2>
              <p className="text-sm text-orange-100">
                Diagnose failed pastries. Use your science knowledge to identify and fix the error.
              </p>
              <div className="flex items-center gap-1 text-orange-200 text-sm font-semibold mt-1">
                Investigate <ChevronRight className="w-4 h-4" />
              </div>
            </Link>
          </motion.div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-sm mb-6">
          {[
            { emoji: "💨", text: "1500× steam expansion" },
            { emoji: "🔬", text: "Starch gelatinization" },
            { emoji: "🥚", text: "Egg protein coagulation" },
          ].map(({ emoji, text }) => (
            <div key={text} className="bg-white/70 rounded-xl px-4 py-2 text-amber-800 font-medium shadow-sm border border-amber-100">
              {emoji} {text}
            </div>
          ))}
        </div>

        <p className="text-sm text-amber-500">No account needed · Runs in your browser</p>
      </motion.div>
    </div>
  );
}