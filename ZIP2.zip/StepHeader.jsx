export default function StepHeader({ step, total, title, subtitle }) {
  return (
    <div className="mb-6">
      <div className="flex items-center gap-2 mb-1">
        {Array.from({ length: total }).map((_, i) => (
          <div
            key={i}
            className={`h-2 rounded-full flex-1 transition-all ${i < step ? "bg-amber-500" : i === step ? "bg-amber-300" : "bg-gray-200"}`}
          />
        ))}
      </div>
      <p className="text-xs text-gray-400 mb-2">Step {step + 1} of {total}</p>
      <h2 className="text-2xl font-bold text-gray-800">{title}</h2>
      {subtitle && <p className="text-sm text-gray-500 mt-1">{subtitle}</p>}
    </div>
  );
}