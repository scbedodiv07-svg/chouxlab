import { motion } from "framer-motion";

const OPTIONS = [
  {
    id: "water",
    emoji: "💧",
    label: "Water",
    desc: "High vapor pressure → maximum rise & crispiness. Pale colour.",
    bg: "bg-blue-50 border-blue-300",
    selected: "bg-blue-500 border-blue-500 text-white",
    tag: "Highest Rise",
    tagColor: "bg-blue-100 text-blue-700",
  },
  {
    id: "milk",
    emoji: "🥛",
    label: "Whole Milk",
    desc: "Lactose triggers Maillard reaction. Golden colour, softer texture.",
    bg: "bg-yellow-50 border-yellow-300",
    selected: "bg-yellow-500 border-yellow-500 text-white",
    tag: "Best Browning",
    tagColor: "bg-yellow-100 text-yellow-700",
  },
  {
    id: "blend",
    emoji: "🫙",
    label: "50/50 Blend",
    desc: "Balanced steam and Maillard. Moderate rise and colour.",
    bg: "bg-amber-50 border-amber-300",
    selected: "bg-amber-500 border-amber-500 text-white",
    tag: "Balanced",
    tagColor: "bg-amber-100 text-amber-700",
  },
];

export default function LiquidSelection({ value, onChange }) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
      {OPTIONS.map((opt) => {
        const isSelected = value === opt.id;
        return (
          <motion.button
            key={opt.id}
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={() => onChange(opt.id)}
            className={`rounded-2xl border-2 p-5 text-left transition-all shadow-sm ${isSelected ? opt.selected : opt.bg}`}
          >
            <div className="text-3xl mb-2">{opt.emoji}</div>
            <div className={`text-xs font-bold px-2 py-0.5 rounded-full inline-block mb-2 ${isSelected ? "bg-white/30 text-white" : opt.tagColor}`}>
              {opt.tag}
            </div>
            <h3 className={`font-bold text-lg mb-1 ${isSelected ? "text-white" : "text-gray-800"}`}>{opt.label}</h3>
            <p className={`text-xs leading-relaxed ${isSelected ? "text-white/90" : "text-gray-500"}`}>{opt.desc}</p>
          </motion.button>
        );
      })}
    </div>
  );
}