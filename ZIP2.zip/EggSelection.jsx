import { motion } from "framer-motion";
import { Lock } from "lucide-react";

export default function EggSelection({ value, onChange, panadeWet }) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
      {/* Low eggs */}
      <motion.button
        whileHover={{ scale: 1.02 }}
        whileTap={{ scale: 0.98 }}
        onClick={() => onChange("low")}
        className={`rounded-2xl border-2 p-6 text-left transition-all shadow-sm ${
          value === "low"
            ? "bg-amber-500 border-amber-500 text-white"
            : "bg-amber-50 border-amber-200 hover:border-amber-400"
        }`}
      >
        <div className="text-3xl mb-2">🥚</div>
        <h3 className={`font-bold text-lg mb-1 ${value === "low" ? "text-white" : "text-gray-800"}`}>Low Egg Count</h3>
        <p className={`text-xs leading-relaxed ${value === "low" ? "text-white/90" : "text-gray-500"}`}>
          2 eggs. Thicker walls, smaller cavity. Lower albumin means weaker "architectural" support.
        </p>
        <div className={`mt-2 text-xs font-semibold px-2 py-0.5 rounded-full inline-block ${value === "low" ? "bg-white/30 text-white" : "bg-amber-100 text-amber-700"}`}>
          Standard
        </div>
      </motion.button>

      {/* High eggs */}
      <motion.button
        whileHover={panadeWet ? {} : { scale: 1.02 }}
        whileTap={panadeWet ? {} : { scale: 0.98 }}
        onClick={() => !panadeWet && onChange("high")}
        className={`rounded-2xl border-2 p-6 text-left transition-all shadow-sm relative ${
          panadeWet
            ? "bg-gray-100 border-gray-200 cursor-not-allowed opacity-60"
            : value === "high"
            ? "bg-orange-500 border-orange-500 text-white"
            : "bg-orange-50 border-orange-200 hover:border-orange-400"
        }`}
      >
        {panadeWet && (
          <div className="absolute top-3 right-3 bg-red-100 rounded-full p-1">
            <Lock className="w-4 h-4 text-red-500" />
          </div>
        )}
        <div className="text-3xl mb-2">🥚🥚🥚</div>
        <h3 className={`font-bold text-lg mb-1 ${value === "high" && !panadeWet ? "text-white" : "text-gray-800"}`}>High Egg Count</h3>
        <p className={`text-xs leading-relaxed ${value === "high" && !panadeWet ? "text-white/90" : "text-gray-500"}`}>
          3–4 eggs. High albumin creates strong walls and large central cavity. Requires a dry panade to absorb.
        </p>
        {panadeWet ? (
          <div className="mt-2 text-xs font-semibold px-2 py-0.5 rounded-full inline-block bg-red-100 text-red-600">
            🔒 Locked — Wet Panade
          </div>
        ) : (
          <div className={`mt-2 text-xs font-semibold px-2 py-0.5 rounded-full inline-block ${value === "high" ? "bg-white/30 text-white" : "bg-orange-100 text-orange-700"}`}>
            Maximum Cavity
          </div>
        )}
      </motion.button>

      {panadeWet && (
        <div className="md:col-span-2 bg-red-50 border border-red-200 rounded-xl p-3 text-sm text-red-700">
          🔒 <strong>High Egg is locked</strong> because the panade was underdried (saturated). A wet panade cannot absorb the additional egg proteins needed for a high-albumin structure.
        </div>
      )}
    </div>
  );
}