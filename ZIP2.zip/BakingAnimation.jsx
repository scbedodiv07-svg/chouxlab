import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";

export default function BakingAnimation({ shape, profile, thermalPhase }) {
  const [phase, setPhase] = useState("raw");

  useEffect(() => {
    const t1 = setTimeout(() => setPhase("expanding"), 600);
    const t2 = setTimeout(() => setPhase("done"), 2800);
    return () => { clearTimeout(t1); clearTimeout(t2); };
  }, []);

  const isFlat = shape === "flat";
  const isChurro = shape === "churro";
  const isLarge = shape === "profiterole-large";
  const isFry = thermalPhase === "fry";

  const shellColor =
    profile?.browning >= 4 ? "#92400e" :
    profile?.browning >= 3 ? "#c8860a" : "#d4a84b";

  const finalW = isFlat ? 180 : isChurro ? 80 : isLarge ? 160 : 130;
  const finalH = isFlat ? 35 : isChurro ? 180 : isLarge ? 140 : 110;
  const cavityW = isLarge ? 90 : isChurro ? 30 : isFlat ? 0 : 60;
  const cavityH = isLarge ? 80 : isChurro ? 120 : isFlat ? 0 : 50;

  const outerW = phase === "raw" ? 50 : finalW;
  const outerH = phase === "raw" ? 40 : finalH;
  const showCavity = phase === "done" && !isFlat;

  const phaseLabel = {
    raw: "Piping dough…",
    expanding: isFry ? "Frying — rapid heat transfer!" : "Steam expanding ~1500× inside!",
    done: "Structure set!",
  }[phase];

  const shapeLabel = isFlat
    ? "Flat Disc (Failed)"
    : isChurro
    ? "Churro (Dense)"
    : isLarge
    ? "Profiterole (Large Cavity)"
    : "Profiterole";

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="fixed inset-0 bg-black/60 flex items-center justify-center z-50"
    >
      <div className="bg-white rounded-3xl p-8 text-center shadow-2xl w-80 flex flex-col items-center gap-4">
        <div className="flex items-center gap-2">
          <span className="text-2xl">{isFry ? "🫕" : "🔥"}</span>
          <h2 className="text-xl font-bold text-amber-800">
            {isFry ? "Frying…" : "Baking…"}
          </h2>
        </div>

        <div className="relative flex items-center justify-center" style={{ width: 220, height: 220 }}>
          {/* Glow */}
          <motion.div
            animate={{ opacity: phase === "expanding" ? [0.3, 0.7, 0.3] : 0 }}
            transition={{ repeat: Infinity, duration: 1.2 }}
            className="absolute inset-0 rounded-full"
            style={{ background: isFry ? "radial-gradient(circle, #fbbf2444, transparent 70%)" : "radial-gradient(circle, #f9731644, transparent 70%)" }}
          />

          {/* Shell */}
          <motion.div
            animate={{ width: outerW, height: outerH }}
            transition={{ duration: 1.6, ease: "easeOut" }}
            style={{
              backgroundColor: shellColor,
              borderRadius: isChurro ? "8px" : isFlat ? "8px" : "50%",
              boxShadow: "0 4px 24px rgba(0,0,0,0.2)",
              position: "absolute",
            }}
          />

          {/* Cavity */}
          <AnimatePresence>
            {showCavity && (
              <motion.div
                initial={{ width: 0, height: 0, opacity: 0 }}
                animate={{ width: cavityW, height: cavityH, opacity: 1 }}
                transition={{ duration: 0.5, ease: "easeOut" }}
                style={{
                  backgroundColor: "#fef3c7",
                  borderRadius: isChurro ? "4px" : "50%",
                  position: "absolute",
                  zIndex: 2,
                  border: "1px dashed #f59e0b44",
                }}
              />
            )}
          </AnimatePresence>

          {/* Steam */}
          <AnimatePresence>
            {phase === "expanding" && [0,1,2,3,4,5].map((i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 0, x: (i - 3) * 12 }}
                animate={{ opacity: [0, 0.7, 0], y: -70 - i * 8 }}
                transition={{ duration: 1.2, delay: i * 0.15, repeat: Infinity }}
                className="absolute text-lg"
                style={{ bottom: "55%", zIndex: 10 }}
              >
                💨
              </motion.div>
            ))}
          </AnimatePresence>
        </div>

        <AnimatePresence mode="wait">
          <motion.p
            key={phase}
            initial={{ opacity: 0, y: 6 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -6 }}
            className="text-sm text-gray-500 font-medium"
          >
            {phaseLabel}
          </motion.p>
        </AnimatePresence>

        <AnimatePresence>
          {phase === "done" && (
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className="bg-amber-50 border border-amber-200 rounded-xl px-4 py-2"
            >
              <p className="text-amber-800 font-semibold text-sm">{shapeLabel}</p>
              <p className="text-xs text-amber-500 mt-0.5">Navigating to your results…</p>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </motion.div>
  );
}