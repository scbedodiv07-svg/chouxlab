import { useState, useEffect, useRef } from "react";
import { Button } from "@/components/ui/button";
import { motion, AnimatePresence } from "framer-motion";

const REQUIRED_CLICKS = 20;

export default function PanadeMiniGame({ onComplete }) {
  const [clicks, setClicks] = useState(0);
  const [done, setDone] = useState(false);
  const [wet, setWet] = useState(false);
  const [abandoned, setAbandoned] = useState(false);
  const timerRef = useRef(null);

  const progress = Math.min(100, (clicks / REQUIRED_CLICKS) * 100);
  const isFilmFormed = clicks >= REQUIRED_CLICKS;

  const handleStir = () => {
    if (done) return;
    const next = clicks + 1;
    setClicks(next);
    if (next >= REQUIRED_CLICKS) {
      setDone(true);
      setWet(false);
      clearTimeout(timerRef.current);
    }
  };

  const handleStop = () => {
    if (done || clicks === 0) return;
    setAbandoned(true);
    setWet(true);
    setDone(true);
  };

  const reset = () => {
    setClicks(0);
    setDone(false);
    setWet(false);
    setAbandoned(false);
  };

  const confirm = () => onComplete(wet);

  const stageColor = clicks < 8 ? "bg-blue-300" : clicks < 16 ? "bg-yellow-400" : "bg-amber-500";
  const stageLabel = clicks < 8 ? "Mixture heating…" : clicks < 16 ? "Starch absorbing liquid…" : "Starch film forming!";

  return (
    <div className="flex flex-col items-center gap-5">
      {/* Pan visual */}
      <div className="relative w-64 h-40 bg-gray-800 rounded-b-full rounded-t-lg flex items-center justify-center shadow-xl overflow-hidden border-4 border-gray-600">
        <motion.div
          className={`absolute bottom-0 left-0 right-0 rounded-b-full transition-all duration-300 ${stageColor}`}
          style={{ height: `${20 + progress * 0.6}%` }}
        />
        <div className="relative z-10 text-center">
          <p className="text-white text-xs font-semibold">{done ? (wet ? "⚠️ Saturated/Wet" : "✅ Starch Film Formed") : stageLabel}</p>
        </div>
        {/* Stirring spoon animation */}
        {!done && (
          <motion.div
            className="absolute text-2xl"
            animate={{ rotate: [0, 15, -15, 0] }}
            transition={{ repeat: Infinity, duration: 0.5 }}
          >
            🥄
          </motion.div>
        )}
      </div>

      {/* Progress bar */}
      <div className="w-full max-w-sm">
        <div className="flex justify-between text-xs text-gray-500 mb-1">
          <span>Stirring Progress</span>
          <span>{Math.round(progress)}%</span>
        </div>
        <div className="h-4 bg-gray-200 rounded-full overflow-hidden">
          <motion.div
            className={`h-full rounded-full ${isFilmFormed ? "bg-amber-500" : "bg-blue-400"}`}
            style={{ width: `${progress}%` }}
            transition={{ duration: 0.1 }}
          />
        </div>
        <p className="text-xs text-gray-400 mt-1 text-center">Target: starch film formation</p>
      </div>

      {!done ? (
        <div className="flex gap-3">
          <Button
            onClick={handleStir}
            className="bg-amber-600 hover:bg-amber-700 text-white px-8 py-6 text-lg rounded-2xl font-bold shadow-lg active:scale-95 transition-transform"
          >
            🥄 Stir!
          </Button>
          {clicks > 0 && (
            <Button variant="outline" onClick={handleStop} className="px-5 py-6 text-sm text-gray-500">
              Stop Early
            </Button>
          )}
        </div>
      ) : (
        <AnimatePresence>
          <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="text-center space-y-3">
            <div className={`rounded-xl px-6 py-3 font-semibold ${wet ? "bg-red-50 border border-red-300 text-red-700" : "bg-green-50 border border-green-300 text-green-700"}`}>
              {wet
                ? "⚠️ Panade is Saturated/Wet — High Egg option will be locked!"
                : "✅ Starch film formed — Panade is dry and ready!"}
            </div>
            <div className="flex gap-2 justify-center">
              <Button variant="outline" onClick={reset} className="text-sm">Try Again</Button>
              <Button onClick={confirm} className="bg-amber-600 hover:bg-amber-700 text-white">Continue →</Button>
            </div>
          </motion.div>
        </AnimatePresence>
      )}

      <p className="text-xs text-gray-400 text-center max-w-xs">
        Click "Stir!" rapidly to dry the panade. Stop too early and it becomes saturated — locking the High Egg option.
      </p>
    </div>
  );
}