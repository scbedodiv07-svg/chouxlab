import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { ChevronLeft, ChevronRight, RotateCcw, CheckCircle2, XCircle, Clipboard } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { createPageUrl } from "@/utils";
import { Link } from "react-router-dom";
import { FORENSICS_SCENARIOS } from "../components/lab/forensicsData";

const SHAPE_STYLES = {
  collapsed: { width: 160, height: 28, borderRadius: "8px", bg: "#92400e" },
  flat: { width: 170, height: 22, borderRadius: "6px", bg: "#b45309" },
  cracked: { width: 120, height: 110, borderRadius: "50%", bg: "#c8860a" },
};

function FailedPastryVisual({ type }) {
  const style = SHAPE_STYLES[type] || SHAPE_STYLES.flat;
  return (
    <div className="flex flex-col items-center gap-2 py-4">
      <p className="text-xs text-gray-400 font-semibold uppercase tracking-widest mb-1">Failed Pastry — Cross Section</p>
      <motion.div
        initial={{ scale: 0.8, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ type: "spring", duration: 0.5 }}
        className="relative flex items-center justify-center"
        style={{ width: 200, height: 140 }}
      >
        <div
          style={{
            width: style.width,
            height: style.height,
            backgroundColor: style.bg,
            borderRadius: style.borderRadius,
            boxShadow: "0 4px 20px rgba(0,0,0,0.2)",
            position: "absolute",
          }}
        />
        {/* Crack lines for cracked type */}
        {type === "cracked" && (
          <svg style={{ position: "absolute", width: 120, height: 110 }} viewBox="0 0 120 110">
            <line x1="70" y1="10" x2="85" y2="45" stroke="#7c2d12" strokeWidth="2.5" strokeLinecap="round" />
            <line x1="45" y1="15" x2="35" y2="50" stroke="#7c2d12" strokeWidth="2" strokeLinecap="round" />
            <line x1="60" y1="5" x2="65" y2="30" stroke="#7c2d12" strokeWidth="1.5" strokeLinecap="round" />
          </svg>
        )}
        {/* Moisture drips for collapsed */}
        {type === "collapsed" && (
          <div className="absolute -bottom-2 flex gap-3">
            {[0, 1, 2].map((i) => (
              <motion.div
                key={i}
                className="w-1 h-2 bg-blue-400 rounded-full opacity-70"
                animate={{ y: [0, 4, 0] }}
                transition={{ repeat: Infinity, duration: 1.2, delay: i * 0.3 }}
              />
            ))}
          </div>
        )}
      </motion.div>
      <span className="text-xs text-red-500 font-semibold mt-2">
        {type === "collapsed" ? "❌ Collapsed — Interior moist & underdone" :
         type === "flat" ? "❌ Never rose — Dense, no cavity" :
         "⚠️ Crust cracked — Uneven expansion"}
      </span>
    </div>
  );
}

function BakersLog({ log }) {
  return (
    <div className="bg-amber-50 border border-amber-200 rounded-xl p-4">
      <div className="flex items-center gap-2 mb-3">
        <Clipboard className="w-4 h-4 text-amber-700" />
        <h3 className="font-bold text-amber-800 text-sm">Baker's Log</h3>
      </div>
      <table className="w-full text-sm">
        <tbody>
          {log.map(({ variable, value, isError }) => (
            <tr key={variable} className={`border-b border-amber-100 last:border-0 ${isError ? "bg-red-50" : ""}`}>
              <td className="py-1.5 pr-3 font-semibold text-gray-600 w-1/3">{variable}</td>
              <td className={`py-1.5 font-medium ${isError ? "text-red-600" : "text-gray-800"}`}>{value}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default function Forensics() {
  const [scenarioIdx, setScenarioIdx] = useState(0);
  const [selected, setSelected] = useState(null);
  const [feedback, setFeedback] = useState(null);
  const [progress, setProgress] = useState(() => {
    const saved = localStorage.getItem("forensicsProgress");
    return saved ? JSON.parse(saved) : {};
  });

  const scenario = FORENSICS_SCENARIOS[scenarioIdx];
  const isCorrect = feedback && selected && FORENSICS_SCENARIOS[scenarioIdx].options.find(o => o.id === selected)?.correct;
  const allSolved = FORENSICS_SCENARIOS.every((s) => progress[s.id]);

  useEffect(() => {
    localStorage.setItem("forensicsProgress", JSON.stringify(progress));
  }, [progress]);

  const handleSelect = (optId) => {
    if (feedback) return;
    setSelected(optId);
  };

  const handleSubmit = () => {
    if (!selected) return;
    const opt = scenario.options.find(o => o.id === selected);
    setFeedback(opt);
    if (opt.correct) {
      setProgress(prev => ({ ...prev, [scenario.id]: true }));
    }
  };

  const handleNext = () => {
    setSelected(null);
    setFeedback(null);
    setScenarioIdx((i) => Math.min(i + 1, FORENSICS_SCENARIOS.length - 1));
  };

  const handleReset = () => {
    setSelected(null);
    setFeedback(null);
    setProgress({});
    localStorage.removeItem("forensicsProgress");
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 to-amber-50">
      <header className="bg-orange-800 text-white px-6 py-4 shadow-md">
        <div className="max-w-4xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Link to={createPageUrl("Home")} className="hover:opacity-80 transition-opacity">
              <ChevronLeft className="w-5 h-5" />
            </Link>
            <span className="text-xl">🔍</span>
            <h1 className="text-lg font-bold">Culinary Forensics</h1>
          </div>
          <div className="flex items-center gap-3">
            <span className="text-sm text-orange-200">
              {Object.keys(progress).length}/{FORENSICS_SCENARIOS.length} solved
            </span>
            <Button variant="ghost" size="sm" className="text-white hover:bg-orange-700" onClick={handleReset}>
              <RotateCcw className="w-4 h-4 mr-1" /> Reset
            </Button>
          </div>
        </div>
      </header>

      <div className="max-w-4xl mx-auto p-5">
        {/* Scenario selector */}
        <div className="flex gap-2 mb-5">
          {FORENSICS_SCENARIOS.map((s, i) => (
            <button
              key={s.id}
              onClick={() => { setScenarioIdx(i); setSelected(null); setFeedback(null); }}
              className={`flex-1 py-2 rounded-xl text-sm font-semibold border-2 transition-all ${
                i === scenarioIdx
                  ? "bg-orange-700 border-orange-700 text-white"
                  : progress[s.id]
                  ? "bg-green-50 border-green-400 text-green-700"
                  : "bg-white border-gray-200 text-gray-600 hover:border-orange-300"
              }`}
            >
              {progress[s.id] ? "✅" : `Case ${i + 1}`}
            </button>
          ))}
        </div>

        <AnimatePresence mode="wait">
          <motion.div
            key={scenarioIdx}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            transition={{ duration: 0.25 }}
          >
            {/* Title & description */}
            <div className="bg-white rounded-2xl border border-orange-100 shadow-sm p-5 mb-4">
              <div className="flex items-start gap-3 mb-3">
                <span className="text-3xl">🔍</span>
                <div>
                  <h2 className="text-xl font-bold text-gray-800">{scenario.title}</h2>
                  <p className="text-sm text-gray-500 mt-0.5">Forensic Case #{scenarioIdx + 1}</p>
                </div>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <FailedPastryVisual type={scenario.failureType} />
                <div>
                  <h3 className="font-semibold text-gray-700 text-sm mb-2">🧪 Forensic Description</h3>
                  <p className="text-sm text-gray-600 leading-relaxed bg-orange-50 rounded-xl p-3 border border-orange-100">
                    {scenario.description}
                  </p>
                </div>
              </div>
            </div>

            {/* Baker's Log */}
            <div className="mb-4">
              <BakersLog log={scenario.bakersLog} />
            </div>

            {/* Multiple choice */}
            <div className="bg-white rounded-2xl border border-orange-100 shadow-sm p-5 mb-4">
              <h3 className="font-bold text-gray-800 mb-3">🛠️ How would you fix this?</h3>
              <div className="space-y-3">
                {scenario.options.map((opt) => {
                  const isSelected = selected === opt.id;
                  const showResult = !!feedback;
                  const isThisCorrect = opt.correct;
                  let border = "border-gray-200 hover:border-orange-300";
                  let bg = "bg-white";
                  if (showResult && isSelected && isThisCorrect) { border = "border-green-500"; bg = "bg-green-50"; }
                  if (showResult && isSelected && !isThisCorrect) { border = "border-red-400"; bg = "bg-red-50"; }
                  if (!showResult && isSelected) { border = "border-orange-400"; bg = "bg-orange-50"; }

                  return (
                    <button
                      key={opt.id}
                      onClick={() => handleSelect(opt.id)}
                      disabled={!!feedback}
                      className={`w-full text-left rounded-xl border-2 p-4 transition-all ${border} ${bg} ${feedback ? "cursor-default" : "cursor-pointer"}`}
                    >
                      <div className="flex items-start gap-3">
                        <span className="font-bold text-gray-500 text-sm mt-0.5 w-5">{opt.id}.</span>
                        <span className="text-sm text-gray-700 flex-1">{opt.text}</span>
                        {showResult && isSelected && (
                          isThisCorrect
                            ? <CheckCircle2 className="w-5 h-5 text-green-500 flex-shrink-0" />
                            : <XCircle className="w-5 h-5 text-red-400 flex-shrink-0" />
                        )}
                      </div>
                    </button>
                  );
                })}
              </div>

              {!feedback && (
                <div className="flex justify-end mt-4">
                  <Button
                    onClick={handleSubmit}
                    disabled={!selected}
                    className="bg-orange-700 hover:bg-orange-800 text-white px-8 py-4 rounded-xl font-semibold"
                  >
                    Submit Answer
                  </Button>
                </div>
              )}
            </div>

            {/* Feedback panel */}
            <AnimatePresence>
              {feedback && (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className={`rounded-2xl p-5 mb-4 border-2 ${isCorrect ? "bg-green-50 border-green-400" : "bg-red-50 border-red-300"}`}
                >
                  <div className="flex items-start gap-3">
                    <span className="text-2xl">{isCorrect ? "✅" : "❌"}</span>
                    <div>
                      <h3 className={`font-bold mb-1 ${isCorrect ? "text-green-800" : "text-red-700"}`}>
                        {isCorrect ? "Correct!" : "Not quite…"}
                      </h3>
                      <p className="text-sm leading-relaxed text-gray-700">{feedback.feedback}</p>
                    </div>
                  </div>

                  <div className="flex justify-end gap-3 mt-4">
                    {!isCorrect && (
                      <Button variant="outline" onClick={() => setFeedback(null)} className="text-sm">
                        Try Again
                      </Button>
                    )}
                    {isCorrect && scenarioIdx < FORENSICS_SCENARIOS.length - 1 && (
                      <Button onClick={handleNext} className="bg-green-600 hover:bg-green-700 text-white">
                        Next Case <ChevronRight className="w-4 h-4 ml-1" />
                      </Button>
                    )}
                    {isCorrect && scenarioIdx === FORENSICS_SCENARIOS.length - 1 && (
                      <Link to={createPageUrl("Home")}>
                        <Button className="bg-amber-600 hover:bg-amber-700 text-white">🏆 All Cases Solved!</Button>
                      </Link>
                    )}
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </motion.div>
        </AnimatePresence>
      </div>
    </div>
  );
}