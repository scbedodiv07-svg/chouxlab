import { useState } from "react";
import { Button } from "@/components/ui/button";
import { FlaskConical, ChevronLeft, RotateCcw } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { createPageUrl } from "@/utils";
import { Link, useNavigate } from "react-router-dom";

import StepHeader from "../components/experiment/StepHeader";
import LiquidSelection from "../components/experiment/LiquidSelection";
import PanadeMiniGame from "../components/experiment/PanadeMiniGame";
import EggSelection from "../components/experiment/EggSelection";
import ThermalSelection from "../components/experiment/ThermalSelection";
import BakingAnimation from "../components/experiment/BakingAnimation";
import { computeProfile, getMorphDescription, getCrossSection } from "../components/lab/pastryEngine";

const STEPS = [
  { title: "Choose Your Liquid", subtitle: "Select the liquid base for your panade. This affects steam pressure and the Maillard reaction." },
  { title: "Cook the Panade", subtitle: "Stir the mixture on the stovetop until a starch film forms. Don't stop too early!" },
  { title: "Add Eggs", subtitle: "Choose how many eggs to incorporate. The panade's dryness determines how many it can absorb." },
  { title: "Select Heat Method", subtitle: "Decide how you'll cook the choux. Baking and frying produce very different results." },
];

export default function Experiment() {
  const navigate = useNavigate();
  const [step, setStep] = useState(0);
  const [liquid, setLiquid] = useState("water");
  const [panadeWet, setPanadeWet] = useState(false);
  const [eggs, setEggs] = useState("low");
  const [thermalPhase, setThermalPhase] = useState("bake");
  const [baking, setBaking] = useState(false);
  const [result, setResult] = useState(null);

  const handlePanadeComplete = (wet) => {
    setPanadeWet(wet);
    if (wet && eggs === "high") setEggs("low");
    setStep(2);
  };

  const handleNext = () => {
    if (step === 0) setStep(1);
    else if (step === 2) setStep(3);
    else if (step === 3) bake();
  };

  const bake = () => {
    const params = { liquid, panadeWet, eggs, thermalPhase };
    const profile = computeProfile(params);
    const description = getMorphDescription(params);
    const shape = getCrossSection(params);
    const resultsObj = { profile, description, shape, params };
    localStorage.setItem("masterDoughResult", JSON.stringify(resultsObj));
    setBaking(true);
    setResult(resultsObj);
    // Navigate after animation completes (4.5s)
    setTimeout(() => {
      navigate(createPageUrl("Results"));
    }, 4500);
  };

  const reset = () => {
    setStep(0);
    setLiquid("water");
    setPanadeWet(false);
    setEggs("low");
    setThermalPhase("bake");
    setResult(null);
    setBaking(false);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-amber-50 to-orange-50">
      <header className="bg-amber-700 text-white px-6 py-4 shadow-md">
        <div className="max-w-3xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Link to={createPageUrl("Home")} className="hover:opacity-80 transition-opacity">
              <ChevronLeft className="w-5 h-5" />
            </Link>
            <FlaskConical className="w-5 h-5" />
            <h1 className="text-lg font-bold">Master Dough Simulation</h1>
          </div>
          <Button variant="ghost" size="sm" className="text-white hover:bg-amber-600" onClick={reset}>
            <RotateCcw className="w-4 h-4 mr-1" /> Reset
          </Button>
        </div>
      </header>

      <div className="max-w-3xl mx-auto p-5">
        <StepHeader step={step} total={STEPS.length} title={STEPS[step].title} subtitle={STEPS[step].subtitle} />

        <AnimatePresence mode="wait">
          <motion.div
            key={step}
            initial={{ opacity: 0, x: 30 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -30 }}
            transition={{ duration: 0.25 }}
            className="bg-white rounded-2xl shadow-sm border border-amber-100 p-6 mb-6"
          >
            {step === 0 && <LiquidSelection value={liquid} onChange={setLiquid} />}
            {step === 1 && <PanadeMiniGame onComplete={handlePanadeComplete} />}
            {step === 2 && <EggSelection value={eggs} onChange={setEggs} panadeWet={panadeWet} />}
            {step === 3 && <ThermalSelection value={thermalPhase} onChange={setThermalPhase} />}
          </motion.div>
        </AnimatePresence>

        {/* Navigation — not shown on step 1 (mini-game handles its own confirm) */}
        {step !== 1 && (
          <div className="flex justify-end">
            <Button
              onClick={handleNext}
              disabled={baking}
              className="bg-amber-600 hover:bg-amber-700 text-white px-8 py-5 text-base font-semibold rounded-xl"
            >
              {baking ? (thermalPhase === "fry" ? "Frying…" : "Baking…") : step === 3 ? (thermalPhase === "fry" ? "🔥 Fry It!" : "🔥 Bake It!") : "Next →"}
            </Button>
          </div>
        )}

        {baking && result && (
          <BakingAnimation shape={result.shape} profile={result.profile} thermalPhase={thermalPhase} />
        )}
      </div>
    </div>
  );
}