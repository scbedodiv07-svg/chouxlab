import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { ChevronLeft, RotateCcw, Search } from "lucide-react";
import { createPageUrl } from "@/utils";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";

import PastryRadarChart from "../components/results/RadarChart";
import CrossSection from "../components/results/CrossSection";
import ProfileMetrics from "../components/results/ProfileMetrics";

const LIQUID_LABEL = { water: "💧 Water", milk: "🥛 Whole Milk", blend: "🫙 50/50 Blend" };
const EGGS_LABEL = { low: "🥚 Low (2 eggs)", high: "🥚🥚🥚 High (3–4 eggs)" };
const THERMAL_LABEL = { bake: "🔥 Bake (Convection)", fry: "🫕 Fry (Immersion)" };

export default function Results() {
  const [result, setResult] = useState(null);

  useEffect(() => {
    const saved = localStorage.getItem("masterDoughResult");
    if (saved) setResult(JSON.parse(saved));
  }, []);

  if (!result) {
    return (
      <div className="min-h-screen bg-amber-50 flex items-center justify-center">
        <div className="text-center p-8">
          <p className="text-gray-500 mb-4">No result found. Run the experiment first!</p>
          <Link to={createPageUrl("Experiment")} className="text-amber-600 underline font-semibold">Go to Experiment →</Link>
        </div>
      </div>
    );
  }

  const { profile, description, shape, params } = result;

  return (
    <div className="min-h-screen bg-gradient-to-br from-amber-50 to-orange-50">
      <header className="bg-amber-700 text-white px-6 py-4 shadow-md">
        <div className="max-w-5xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Link to={createPageUrl("Experiment")} className="hover:opacity-80 transition-opacity">
              <ChevronLeft className="w-5 h-5" />
            </Link>
            <h1 className="text-lg font-bold">Pastry Profile Results</h1>
          </div>
          <div className="flex gap-2">
            <Link to={createPageUrl("Forensics")}>
              <Button variant="outline" size="sm" className="text-amber-700 border-amber-300 bg-white/20 hover:bg-white/30">
                <Search className="w-4 h-4 mr-1" /> Forensics
              </Button>
            </Link>
            <Link to={createPageUrl("Experiment")}>
              <Button variant="ghost" size="sm" className="text-white hover:bg-amber-600">
                <RotateCcw className="w-4 h-4 mr-1" /> Try Again
              </Button>
            </Link>
          </div>
        </div>
      </header>

      <div className="max-w-5xl mx-auto p-5 space-y-6">
        {/* Baker's Log */}
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="bg-white rounded-2xl shadow-sm border border-amber-100 p-5">
          <h2 className="font-bold text-gray-800 mb-3 text-lg">📋 Your Recipe</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {[
              ["Liquid", LIQUID_LABEL[params.liquid]],
              ["Panade", params.panadeWet ? "⚠️ Saturated/Wet" : "✅ Dry"],
              ["Eggs", EGGS_LABEL[params.eggs]],
              ["Heat", THERMAL_LABEL[params.thermalPhase]],
            ].map(([k, v]) => (
              <div key={k} className="bg-amber-50 rounded-xl p-3 border border-amber-100">
                <p className="text-xs text-gray-400 font-semibold uppercase">{k}</p>
                <p className="text-sm font-bold text-gray-800 mt-0.5">{v}</p>
              </div>
            ))}
          </div>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Cross-section */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.1 }}
            className="bg-white rounded-2xl shadow-sm border border-amber-100 p-5 flex flex-col items-center"
          >
            <CrossSection shape={shape} profile={profile} />
          </motion.div>

          {/* Radar chart */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.15 }}
            className="bg-white rounded-2xl shadow-sm border border-amber-100 p-5"
          >
            <h2 className="font-bold text-gray-800 mb-2 text-lg">🕸️ Pastry Profile</h2>
            <PastryRadarChart profile={profile} />
          </motion.div>
        </div>

        {/* Metrics detail */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-white rounded-2xl shadow-sm border border-amber-100 p-5"
        >
          <h2 className="font-bold text-gray-800 mb-4 text-lg">📊 Detailed Metrics</h2>
          <ProfileMetrics profile={profile} />
        </motion.div>

        {/* Morphological description */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.25 }}
          className="bg-amber-700 text-white rounded-2xl shadow-md p-6"
        >
          <h2 className="font-bold text-lg mb-2">🔬 Scientific Analysis</h2>
          <p className="text-sm leading-relaxed text-amber-100">{description}</p>
        </motion.div>
      </div>
    </div>
  );
}