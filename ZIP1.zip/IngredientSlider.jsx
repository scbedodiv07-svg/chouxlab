import { Slider } from "@/components/ui/slider";
import { Badge } from "@/components/ui/badge";

export default function IngredientSlider({ label, value, min, max, step, unit, onChange, color = "amber" }) {
  const colorMap = {
    amber: "bg-amber-500",
    blue: "bg-blue-500",
    yellow: "bg-yellow-500",
  };

  return (
    <div className="mb-5">
      <div className="flex justify-between items-center mb-2">
        <span className="font-medium text-gray-800">{label}</span>
        <Badge variant="outline" className="text-sm font-semibold">
          {value} {unit}
        </Badge>
      </div>
      <Slider
        min={min}
        max={max}
        step={step}
        value={[value]}
        onValueChange={([v]) => onChange(v)}
        className="w-full"
      />
      <div className="flex justify-between text-xs text-gray-400 mt-1">
        <span>{min} {unit}</span>
        <span>{max} {unit}</span>
      </div>
    </div>
  );
}