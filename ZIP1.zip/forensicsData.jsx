/**
 * Culinary Forensics puzzle scenarios.
 * Each scenario has a failed pastry description, baker's log, and multiple-choice correction.
 */
export const FORENSICS_SCENARIOS = [
  {
    id: "collapse",
    title: "The Phantom Collapse",
    failureType: "collapsed",
    description:
      "The pastry was golden and tall in the oven but collapsed into a flat disc immediately upon removal. The interior walls appear moist and under-cooked.",
    bakersLog: [
      { variable: "Liquid Base", value: "Whole Milk" },
      { variable: "Panade", value: "Dry (Starch film formed)" },
      { variable: "Eggs", value: "High" },
      { variable: "Oven Temp", value: "210°C for 10 min, then 150°C for 15 min" },
      { variable: "Venting/Piercing", value: "None ⚠️", isError: true },
    ],
    options: [
      {
        id: "A",
        text: "Increase the amount of milk in the initial liquid base.",
        correct: false,
        feedback:
          "Incorrect. Adding more milk would increase moisture and decrease crispiness further, making the collapse more likely.",
      },
      {
        id: "B",
        text: "Pierce the base of the pastry and return to the oven for 5 minutes (venting).",
        correct: true,
        feedback:
          "Correct! Piercing allows residual steam to escape. This prevents the steam from condensing into water, which weakens the protein walls and causes a vacuum collapse.",
      },
      {
        id: "C",
        text: "Skip the stovetop stirring phase to keep the dough as wet as possible.",
        correct: false,
        feedback:
          "Incorrect. This would result in a 'wetter' panade with lower absorptive capacity for eggs, meaning insufficient albumin to keep the puff standing.",
      },
    ],
  },
  {
    id: "flat",
    title: "The Flat Disc",
    failureType: "flat",
    description:
      "The piped dough spread sideways in the oven and never rose. The result is a flat, pale disc with no internal cavity. It looks more like a cookie than a choux.",
    bakersLog: [
      { variable: "Liquid Base", value: "Water" },
      { variable: "Panade", value: "Saturated/Wet (Under-dried) ⚠️", isError: true },
      { variable: "Eggs", value: "High (forced)" },
      { variable: "Oven Temp", value: "200°C for 25 min" },
      { variable: "Venting/Piercing", value: "Yes" },
    ],
    options: [
      {
        id: "A",
        text: "Increase oven temperature to 230°C.",
        correct: false,
        feedback:
          "Incorrect. The problem is not the temperature — it's the wet panade. Higher heat cannot compensate for a structurally weak dough.",
      },
      {
        id: "B",
        text: "Add more flour to the mixture to thicken the batter.",
        correct: false,
        feedback:
          "Incorrect. More flour changes the ratio and may worsen the gelatinization. The root cause is the undried panade.",
      },
      {
        id: "C",
        text: "Dry the panade properly on the stove until a starch film forms before adding eggs.",
        correct: true,
        feedback:
          "Correct! A properly dried panade (where moisture is cooked off until a starch film coats the pan) has the absorptive capacity to incorporate eggs and build the structural protein network needed to hold steam.",
      },
    ],
  },
  {
    id: "cracked",
    title: "The Cracked Shell",
    failureType: "cracked",
    description:
      "The pastry rose well but developed deep, irregular cracks on the surface. The crust is thick in some areas and paper-thin in others. The interior is partially hollow.",
    bakersLog: [
      { variable: "Liquid Base", value: "Water" },
      { variable: "Panade", value: "Dry (Starch film formed)" },
      { variable: "Eggs", value: "High" },
      { variable: "Oven Temp", value: "240°C throughout ⚠️", isError: true },
      { variable: "Venting/Piercing", value: "Yes" },
    ],
    options: [
      {
        id: "A",
        text: "Switch to whole milk to add fat and reduce surface tension.",
        correct: false,
        feedback:
          "Incorrect. While milk does soften the crust, the primary cause of irregular cracking is excessive heat shock causing uneven steam burst — not the liquid type.",
      },
      {
        id: "B",
        text: "Reduce oven temperature to 190–200°C for a controlled, even rise.",
        correct: true,
        feedback:
          "Correct! At 240°C, the surface sets too quickly before the steam can expand evenly. Reducing to 190–200°C allows a controlled rise where steam pressure builds gradually and the shell expands uniformly.",
      },
      {
        id: "C",
        text: "Use low egg count to reduce the internal steam pressure.",
        correct: false,
        feedback:
          "Incorrect. Reducing eggs would weaken the walls and cavity, but would not solve the surface cracking caused by excessive external heat.",
      },
    ],
  },
];