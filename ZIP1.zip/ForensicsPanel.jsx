import { AlertTriangle, CheckCircle2, HelpCircle } from "lucide-react";

const diagnoses = [
  {
    id: "flat",
    label: "Flat / Didn't Rise",
    icon: AlertTriangle,
    color: "red",
    causes: [
      "Too little liquid → insufficient steam",
      "Too many eggs → batter too runny",
      "Oven temperature too low → steam escaped slowly",
    ],
    fixes: ["Increase water/milk to 100–120 ml", "Use 2 eggs for standard batch", "Preheat oven to 200°C"],
  },
  {
    id: "cracked",
    label: "Surface Cracks",
    icon: AlertTriangle,
    color: "orange",
    causes: [
      "Oven too hot → rapid uneven steam burst",
      "Too much flour → rigid shell cracks under pressure",
    ],
    fixes: ["Reduce oven to 190°C", "Check flour ratio (standard: 60g per 100ml liquid)"],
  },
  {
    id: "dense",
    label: "Dense / No Hollow",
    icon: AlertTriangle,
    color: "yellow",
    causes: [
      "Too few eggs → walls collapsed inward",
      "Under-baked → steam condensed back",
      "Too little liquid → weak steam pressure",
    ],
    fixes: ["Add one more egg", "Bake for full 25–30 min without opening oven", "Increase liquid by 10–20 ml"],
  },
  {
    id: "perfect",
    label: "Perfect Choux ✓",
    icon: CheckCircle2,
    color: "green",
    causes: [
      "Liquid: 100–120 ml",
      "Flour: 60g",
      "Eggs: 2–3",
      "Oven: 190–200°C",
    ],
    fixes: [],
  },
];

export default function ForensicsPanel({ outcome }) {
  const activeId = outcome?.perfect
    ? "perfect"
    : outcome?.flat
    ? "flat"
    : outcome?.cracked
    ? "cracked"
    : "dense";

  const colorMap = {
    red: { border: "border-red-400", bg: "bg-red-50", text: "text-red-700", icon: "text-red-500" },
    orange: { border: "border-orange-400", bg: "bg-orange-50", text: "text-orange-700", icon: "text-orange-500" },
    yellow: { border: "border-yellow-400", bg: "bg-yellow-50", text: "text-yellow-700", icon: "text-yellow-500" },
    green: { border: "border-green-400", bg: "bg-green-50", text: "text-green-700", icon: "text-green-500" },
  };

  return (
    <div className="space-y-3">
      {diagnoses.map(({ id, label, icon: Icon, color, causes, fixes }) => {
        const isActive = activeId === id;
        const c = colorMap[color];
        return (
          <div
            key={id}
            className={`border-l-4 rounded-lg p-3 transition-all ${c.border} ${c.bg} ${
              isActive ? "shadow-md" : "opacity-50"
            }`}
          >
            <div className={`flex items-center gap-2 font-semibold text-sm mb-1 ${c.text}`}>
              <Icon className={`w-4 h-4 ${c.icon}`} />
              {label}
            </div>
            {isActive && causes.length > 0 && (
              <>
                <p className="text-xs text-gray-500 font-semibold mb-1">Possible causes:</p>
                <ul className="list-disc list-inside text-xs text-gray-600 space-y-0.5 mb-2">
                  {causes.map((c) => <li key={c}>{c}</li>)}
                </ul>
                {fixes.length > 0 && (
                  <>
                    <p className="text-xs text-gray-500 font-semibold mb-1">Fixes:</p>
                    <ul className="list-disc list-inside text-xs text-gray-600 space-y-0.5">
                      {fixes.map((f) => <li key={f}>{f}</li>)}
                    </ul>
                  </>
                )}
              </>
            )}
          </div>
        );
      })}
    </div>
  );
}