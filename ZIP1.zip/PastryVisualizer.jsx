import { motion } from "framer-motion";

/**
 * Renders a cross-section of the choux pastry shape based on computed outcome.
 * outcome: { hollow: boolean, cracked: boolean, flat: boolean, perfect: boolean, size: number (0-1) }
 */
export default function PastryVisualizer({ outcome, stage }) {
  const { hollow, cracked, flat, perfect, size } = outcome;

  // Base dimensions
  const baseWidth = 120 + size * 80; // 120px to 200px
  const baseHeight = flat ? 40 + size * 20 : 80 + size * 60;

  const shellColor = perfect
    ? "#c8860a"
    : flat
    ? "#a07030"
    : cracked
    ? "#b07820"
    : "#c8860a";

  const innerColor = hollow ? "#fef3c7" : "#d97706";
  const innerHeight = hollow ? baseHeight * 0.5 : baseHeight * 0.2;
  const innerWidth = hollow ? baseWidth * 0.6 : baseWidth * 0.3;

  const stageLabels = {
    raw: "Raw Dough",
    oven: "In the Oven",
    baked: "Baked Result",
  };

  return (
    <div className="flex flex-col items-center gap-3">
      <p className="text-sm font-semibold text-gray-500 uppercase tracking-wide">
        {stageLabels[stage] || "Result"}
      </p>

      <motion.div
        key={`${baseWidth}-${baseHeight}-${stage}`}
        initial={{ scale: 0.8, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ duration: 0.5, type: "spring" }}
        className="relative flex items-center justify-center"
        style={{ width: 220, height: 160 }}
      >
        {/* Outer shell */}
        <div
          style={{
            width: baseWidth,
            height: baseHeight,
            backgroundColor: shellColor,
            borderRadius: flat ? "10px" : "50%",
            position: "absolute",
            boxShadow: "0 4px 20px rgba(0,0,0,0.15)",
          }}
        />

        {/* Hollow interior */}
        {hollow && stage === "baked" && (
          <div
            style={{
              width: innerWidth,
              height: innerHeight,
              backgroundColor: innerColor,
              borderRadius: "50%",
              position: "absolute",
              zIndex: 2,
            }}
          />
        )}

        {/* Crack lines */}
        {cracked && stage === "baked" && (
          <svg
            style={{ position: "absolute", zIndex: 3, width: baseWidth, height: baseHeight }}
            viewBox={`0 0 ${baseWidth} ${baseHeight}`}
          >
            <line x1="60%" y1="10%" x2="75%" y2="40%" stroke="#7c4400" strokeWidth="2" strokeLinecap="round" />
            <line x1="40%" y1="15%" x2="30%" y2="45%" stroke="#7c4400" strokeWidth="1.5" strokeLinecap="round" />
          </svg>
        )}

        {/* Steam animation in oven stage */}
        {stage === "oven" && (
          <div className="absolute -top-8 flex gap-2">
            {[0, 0.3, 0.6].map((delay, i) => (
              <motion.div
                key={i}
                className="w-1 h-6 bg-blue-300 rounded-full opacity-60"
                animate={{ y: [-4, -14, -4], opacity: [0.6, 0.2, 0.6] }}
                transition={{ repeat: Infinity, duration: 1.5, delay }}
              />
            ))}
          </div>
        )}
      </motion.div>

      {/* Status label */}
      <div className="text-center">
        {perfect && <span className="text-green-600 font-semibold text-sm">✓ Perfect Choux!</span>}
        {flat && <span className="text-red-500 font-semibold text-sm">✗ Too Flat / Dense</span>}
        {cracked && !flat && <span className="text-orange-500 font-semibold text-sm">⚠ Surface Cracks</span>}
        {hollow && !perfect && !flat && !cracked && (
          <span className="text-amber-600 font-semibold text-sm">Hollow but not ideal</span>
        )}
      </div>
    </div>
  );
}