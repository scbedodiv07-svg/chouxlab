import { Info } from "lucide-react";

const concepts = {
  steam: {
    title: "Steam Expansion (1500×)",
    body: "Water turns to steam at 100°C and expands ~1500 times in volume. This steam is trapped inside the panade (flour-water matrix), rapidly inflating the pastry shell.",
    color: "blue",
  },
  starch: {
    title: "Starch Gelatinization",
    body: "When flour is cooked in boiling water/milk, starch granules absorb liquid and swell. This creates the viscous panade that holds the steam and gives structure.",
    color: "amber",
  },
  egg: {
    title: "Egg Protein Coagulation",
    body: "Eggs provide proteins that coagulate (set) when heated, forming the rigid outer shell. Too few eggs = thick, dense walls. Too many = batter too runny to hold shape.",
    color: "yellow",
  },
  liquid: {
    title: "Liquid Ratio",
    body: "The water/milk ratio determines gelatinization quality. More water creates more steam but risks a weak structure. Milk adds fats and proteins for colour and flavour.",
    color: "green",
  },
};

export default function SciencePanel({ highlight }) {
  return (
    <div className="space-y-3">
      {Object.entries(concepts).map(([key, { title, body, color }]) => {
        const isHighlighted = highlight === key;
        const borderColor = {
          blue: "border-blue-400 bg-blue-50",
          amber: "border-amber-400 bg-amber-50",
          yellow: "border-yellow-400 bg-yellow-50",
          green: "border-green-400 bg-green-50",
        }[color];
        const textColor = {
          blue: "text-blue-800",
          amber: "text-amber-800",
          yellow: "text-yellow-800",
          green: "text-green-800",
        }[color];

        return (
          <div
            key={key}
            className={`border-l-4 rounded-lg p-3 transition-all ${borderColor} ${
              isHighlighted ? "shadow-md scale-[1.01]" : "opacity-70"
            }`}
          >
            <div className="flex items-center gap-2 mb-1">
              <Info className={`w-4 h-4 ${textColor}`} />
              <span className={`font-semibold text-sm ${textColor}`}>{title}</span>
            </div>
            <p className="text-xs text-gray-600 leading-relaxed">{body}</p>
          </div>
        );
      })}
    </div>
  );
}