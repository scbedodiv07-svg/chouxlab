const METRICS = [
  { key: "rise", label: "Rise", icon: "📈", desc: "Vertical expansion from steam leavening" },
  { key: "cavitySize", label: "Cavity Size", icon: "🕳️", desc: "Volume of the internal hollow" },
  { key: "porosity", label: "Porosity", icon: "🫧", desc: "Small air pockets in the pastry walls" },
  { key: "strength", label: "Strength", icon: "💪", desc: "Structural integrity & resistance to collapse" },
  { key: "browning", label: "Browning", icon: "🟤", desc: "Intensity of the Maillard reaction" },
  { key: "crispiness", label: "Crispiness", icon: "🥐", desc: "Surface dehydration and brittleness" },
  { key: "moistureContent", label: "Moisture", icon: "💧", desc: "Residual hydration in the walls" },
];

function Bar({ value }) {
  const pct = ((value - 1) / 4) * 100;
  const color = value >= 4 ? "bg-green-500" : value >= 3 ? "bg-amber-500" : "bg-red-400";
  return (
    <div className="h-2 bg-gray-100 rounded-full overflow-hidden w-full">
      <div className={`h-full rounded-full ${color} transition-all duration-700`} style={{ width: `${pct}%` }} />
    </div>
  );
}

export default function ProfileMetrics({ profile }) {
  return (
    <div className="space-y-3">
      {METRICS.map(({ key, label, icon, desc }) => (
        <div key={key} className="flex items-center gap-3">
          <span className="text-lg w-6 text-center">{icon}</span>
          <div className="flex-1">
            <div className="flex justify-between items-center mb-0.5">
              <span className="text-sm font-semibold text-gray-700">{label}</span>
              <span className="text-xs font-bold text-gray-500">{profile[key]}/5</span>
            </div>
            <Bar value={profile[key]} />
            <p className="text-xs text-gray-400 mt-0.5">{desc}</p>
          </div>
        </div>
      ))}
    </div>
  );
}