import { motion } from "framer-motion";
import { Flame, Waves } from "lucide-react";

export default function ThermalSelection({ value, onChange }) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
      <motion.button
        whileHover={{ scale: 1.02 }}
        whileTap={{ scale: 0.98 }}
        onClick={() => onChange("bake")}
        className={`rounded-2xl border-2 p-6 text-left transition-all shadow-sm ${
          value === "bake"
            ? "bg-orange-500 border-orange-500 text-white"
            : "bg-orange-50 border-orange-200 hover:border-orange-400"
        }`}
      >
        <Flame className={`w-8 h-8 mb-2 ${value === "bake" ? "text-white" : "text-orange-500"}`} />
        <h3 className={`font-bold text-lg mb-1 ${value === "bake" ? "text-white" : "text-gray-800"}`}>Bake (Convection)</h3>
        <p className={`text-xs leading-relaxed ${value === "bake" ? "text-white/90" : "text-gray-500"}`}>
          Hot air circulates around the dough. Steam builds up inside slowly, creating maximum rise and a crisp shell. Classic profiterole method.
        </p>
        <div className={`mt-3 text-xs font-semibold px-2 py-0.5 rounded-full inline-block ${value === "bake" ? "bg-white/30 text-white" : "bg-orange-100 text-orange-700"}`}>
          High Rise · Crisp Shell
        </div>
      </motion.button>

      <motion.button
        whileHover={{ scale: 1.02 }}
        whileTap={{ scale: 0.98 }}
        onClick={() => onChange("fry")}
        className={`rounded-2xl border-2 p-6 text-left transition-all shadow-sm ${
          value === "fry"
            ? "bg-yellow-600 border-yellow-600 text-white"
            : "bg-yellow-50 border-yellow-200 hover:border-yellow-400"
        }`}
      >
        <Waves className={`w-8 h-8 mb-2 ${value === "fry" ? "text-white" : "text-yellow-600"}`} />
        <h3 className={`font-bold text-lg mb-1 ${value === "fry" ? "text-white" : "text-gray-800"}`}>Fry (Immersion)</h3>
        <p className={`text-xs leading-relaxed ${value === "fry" ? "text-white/90" : "text-gray-500"}`}>
          Submerged in hot oil. Instant surface dehydration and rapid boiling of internal moisture creates an open, porous crumb. Classic churro method.
        </p>
        <div className={`mt-3 text-xs font-semibold px-2 py-0.5 rounded-full inline-block ${value === "fry" ? "bg-white/30 text-white" : "bg-yellow-100 text-yellow-700"}`}>
          Porous · Moist Core
        </div>
      </motion.button>
    </div>
  );
}