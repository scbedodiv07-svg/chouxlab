import { motion } from "framer-motion";

/**
 * shape: "profiterole-large" | "profiterole" | "churro" | "flat"
 */
export default function CrossSection({ shape, profile }) {
  const isFlat = shape === "flat";
  const isChurro = shape === "churro";
  const isLarge = shape === "profiterole-large";

  const outerW = isFlat ? 180 : isChurro ? 80 : isLarge ? 160 : 130;
  const outerH = isFlat ? 35 : isChurro ? 180 : isLarge ? 140 : 110;
  const shellColor = profile?.browning >= 4 ? "#92400e" : profile?.browning >= 3 ? "#c8860a" : "#d4a84b";
  const cavityW = isLarge ? 90 : isChurro ? 30 : isFlat ? 0 : 60;
  const cavityH = isLarge ? 80 : isChurro ? 120 : isFlat ? 0 : 50;
  const cavityColor = "#fef3c7";
  const hasHollow = !isFlat;

  return (
    <div className="flex flex-col items-center gap-2">
      <p className="text-xs font-semibold text-gray-400 uppercase tracking-widest">Cross-Section View</p>
      <motion.div
        key={shape}
        initial={{ scale: 0.7, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ type: "spring", duration: 0.6 }}
        className="relative flex items-center justify-center"
        style={{ width: 220, height: 220 }}
      >
        {/* Outer shell */}
        <div
          style={{
            width: outerW,
            height: outerH,
            backgroundColor: shellColor,
            borderRadius: isChurro ? "8px" : isFlat ? "8px" : "50%",
            boxShadow: "0 4px 24px rgba(0,0,0,0.18)",
            position: "absolute",
          }}
        />
        {/* Hollow interior */}
        {hasHollow && (
          <div
            style={{
              width: cavityW,
              height: cavityH,
              backgroundColor: cavityColor,
              borderRadius: isChurro ? "4px" : "50%",
              position: "absolute",
              zIndex: 2,
              border: "1px dashed #f59e0b44",
            }}
          />
        )}
        {/* Porous texture dots for fry */}
        {isChurro && (
          <div className="absolute inset-0 flex items-center justify-center" style={{ zIndex: 3 }}>
            {[...Array(8)].map((_, i) => (
              <div
                key={i}
                className="absolute rounded-full bg-amber-900 opacity-20"
                style={{
                  width: 6,
                  height: 6,
                  top: `${15 + Math.random() * 70}%`,
                  left: `${30 + Math.random() * 40}%`,
                }}
              />
            ))}
          </div>
        )}
      </motion.div>

      {/* Shape label */}
      <div className="text-center">
        <span className="text-sm font-semibold text-amber-700">
          {isFlat ? "Flat Disc (Failed)" : isChurro ? "Churro (Dense)" : isLarge ? "Profiterole (Large Cavity)" : "Profiterole"}
        </span>
      </div>
    </div>
  );
}