/**
 * Choux Pastry Science Engine
 * Computes the 7-axis Pastry Profile based on user selections.
 * 
 * Inputs:
 *   liquid: "water" | "milk" | "blend"
 *   panadeWet: boolean (true = saturated/underdried)
 *   eggs: "low" | "high"
 *   thermalPhase: "bake" | "fry"
 * 
 * Outputs: { rise, cavitySize, porosity, strength, browning, crispiness, moistureContent } (each 1–5)
 */
export function computeProfile({ liquid, panadeWet, eggs, thermalPhase }) {
  let rise = 3, cavitySize = 3, porosity = 3, strength = 3, browning = 3, crispiness = 3, moistureContent = 3;

  // --- LIQUID EFFECT ---
  if (liquid === "water") {
    rise += 1;         // High vapor pressure
    crispiness += 1;   // Water base → crisp
    browning -= 1;     // Pale, no Maillard
    moistureContent -= 1;
  } else if (liquid === "milk") {
    rise -= 1;         // Moderate rise
    browning += 2;     // Lactose + proteins → Maillard
    crispiness -= 1;   // Soft/tender
    moistureContent += 1;
  } else if (liquid === "blend") {
    browning += 1;
    rise += 0;
  }

  // --- PANADE WET EFFECT ---
  if (panadeWet) {
    rise -= 2;
    cavitySize -= 2;
    strength -= 2;
    moistureContent += 2;
  }

  // --- EGG EFFECT ---
  if (eggs === "high" && !panadeWet) {
    cavitySize += 2;   // Albumin stretch → large cavity
    strength += 1;     // Better walls
    rise += 1;
  } else if (eggs === "low") {
    cavitySize -= 1;
    strength -= 1;
  }

  // --- THERMAL PHASE ---
  if (thermalPhase === "fry") {
    crispiness += 1;
    porosity += 2;     // Rapid boiling creates open crumb
    moistureContent += 1;
    cavitySize -= 1;   // Dense/smaller cavity
  } else if (thermalPhase === "bake") {
    rise += 1;
    crispiness += 1;   // High heat shock
  }

  // Clamp all to 1–5
  const clamp = (v) => Math.min(5, Math.max(1, Math.round(v)));
  return {
    rise: clamp(rise),
    cavitySize: clamp(cavitySize),
    porosity: clamp(porosity),
    strength: clamp(strength),
    browning: clamp(browning),
    crispiness: clamp(crispiness),
    moistureContent: clamp(moistureContent),
  };
}

/**
 * Generates a morphological description based on the profile.
 */
export function getMorphDescription({ liquid, panadeWet, eggs, thermalPhase }) {
  if (panadeWet) {
    return "The under-dried panade lacked the absorptive capacity for sufficient egg proteins. The dough could not hold the steam, resulting in minimal expansion. Result: A flat, dense pastry with moist, underdeveloped walls.";
  }
  if (liquid === "water" && eggs === "high" && thermalPhase === "bake") {
    return "The high vapor pressure of water combined with high albumin content created a 1500-fold steam expansion. Result: A light, crisp profiterole with a massive internal cavity and thin, structurally sound walls.";
  }
  if (liquid === "milk" && eggs === "low" && thermalPhase === "fry") {
    return "The lactose in the milk triggered a rapid Maillard reaction on the surface. The frying created instant surface dehydration with a moist, dense interior. Result: A golden churro with a thick, rigid crust and minimal hollow.";
  }
  if (thermalPhase === "fry") {
    return "Immersion frying caused rapid convective heat transfer and instant surface dehydration, creating a highly porous crumb. Result: A golden, crispy exterior with a moist and open interior.";
  }
  if (liquid === "milk") {
    return "The milk's lactose and proteins promoted the Maillard reaction, yielding a deep golden-brown colour. The fats retained moisture in the walls. Result: A soft, flavourful pastry with moderate rise and a tender crumb.";
  }
  return "Balanced variables produced a well-structured choux pastry. The steam expanded the dough evenly, and egg proteins set the walls. Result: A hollow profiterole with a crisp shell and good structural integrity.";
}

/**
 * Visual shape of the cross-section for the result page.
 */
export function getCrossSection({ liquid, panadeWet, eggs, thermalPhase }) {
  if (panadeWet) return "flat";
  if (thermalPhase === "fry") return "churro";
  if (eggs === "high") return "profiterole-large";
  return "profiterole";
}