import { Radar, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, ResponsiveContainer, Tooltip } from "recharts";

const AXES = [
  { key: "rise", label: "Rise" },
  { key: "cavitySize", label: "Cavity" },
  { key: "porosity", label: "Porosity" },
  { key: "strength", label: "Strength" },
  { key: "browning", label: "Browning" },
  { key: "crispiness", label: "Crispiness" },
  { key: "moistureContent", label: "Moisture" },
];

export default function PastryRadarChart({ profile }) {
  const data = AXES.map(({ key, label }) => ({
    axis: label,
    value: profile[key] ?? 1,
  }));

  return (
    <ResponsiveContainer width="100%" height={300}>
      <RadarChart data={data} margin={{ top: 10, right: 20, bottom: 10, left: 20 }}>
        <PolarGrid stroke="#e5e7eb" />
        <PolarAngleAxis dataKey="axis" tick={{ fontSize: 12, fill: "#6b7280", fontWeight: 600 }} />
        <PolarRadiusAxis domain={[0, 5]} tickCount={6} tick={{ fontSize: 10, fill: "#9ca3af" }} />
        <Radar
          name="Pastry Profile"
          dataKey="value"
          stroke="#d97706"
          fill="#f59e0b"
          fillOpacity={0.4}
          strokeWidth={2}
        />
        <Tooltip
          formatter={(val) => [`${val}/5`, "Rating"]}
          contentStyle={{ fontSize: 12, borderRadius: 8 }}
        />
      </RadarChart>
    </ResponsiveContainer>
  );
}